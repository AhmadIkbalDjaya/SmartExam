<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('quizzes', function (Blueprint $table) {
            $table->id();
            $table->string('quiz_name');
            $table->enum('quiz_category', ['SMP', 'SMA']);
            $table->enum('quiz_type', ['MC', 'ES', 'TF']);
            $table->string('quiz_code');
            $table->dateTime('start_time');
            $table->dateTime('end_time');
            $table->integer('duration')->unsigned()->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('quizzes');
    }
};
