<div class="page-breadcrumb">
  <!-- Question -->
  <section id="header">
    <div class="container-fluid card">
      <div class="row">
        <div class="col-md-12">
          <div class="container-fluid">
            <div class="row p-5">
              <div class="col-md-12 text-center">
                <h3><?php echo e($quiz->quiz_name); ?></h3>
                <p>Pilihan Ganda</p>
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- alerts -->
  <?php echo $__env->make('components.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  <section id="Soal">
    <div class="container-fluid card py-4 px-0">
      <div class="row">
        <div class="col-md-12">
          <div class="container-fluid ">
            <div class="row p-3 card-header shadow-sm">
              <div class="col-md-12">
                <h4 class="py-3">Edit Soal Ujian</h4>
                <form wire:submit.prevent="update(<?php echo e($question_id); ?>)" method="POST">
                  <div class="">
                    <label for="question_body">Pertanyaan</label>
                    <div wire:ignore>
                      <textarea wire:model="question_body" name="question_body" id="question_body" rows="10" cols="80"><?php echo e($question_body); ?></textarea>
                    </div>
                    <?php $__errorArgs = ['question_body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="text-danger">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="">
                    <div wire:ignore>
                      <label for="optionA">Jawaban A</label>
                      <textarea name="optionA" id="optionA" rows="10" cols="80"><?php echo e($optionA); ?></textarea>
                    </div>
                    <?php $__errorArgs = ['optionA'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="text-danger">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="">
                    <div wire:ignore>
                      <label for="optionB">Jawaban B</label>
                      <textarea name="optionB" id="optionB" rows="10" cols="80"><?php echo e($optionB); ?></textarea>
                    </div>
                    <?php $__errorArgs = ['optionB'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="text-danger">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="">
                    <div wire:ignore>
                      <label for="optionC">Jawaban C</label>
                      <textarea name="optionC" id="optionC" rows="10" cols="80"><?php echo e($optionC); ?></textarea>
                    </div>
                    <?php $__errorArgs = ['optionC'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="text-danger">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="">
                    <div wire:ignore>
                      <label for="optionD">Jawaban D</label>
                      <textarea name="optionD" id="optionD" rows="10" cols="80"><?php echo e($optionD); ?></textarea>
                    </div>
                    <?php $__errorArgs = ['optionD'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="text-danger">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="">
                    <div wire:ignore>
                      <label for="optionE">Jawaban E</label>
                      <textarea name="optionE" id="optionE" rows="10" cols="80"><?php echo e($optionE); ?></textarea>
                    </div>
                    <?php $__errorArgs = ['optionE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="text-danger">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="">
                    <div class="container px-0">
                      <div class="row border-bottom py-3">
                        <p>Kunci Jawaban</p>
                        <div class="col-2">
                          <div class="form-check">
                            <input class="form-check-input" wire:model="correct" value="A" type="radio"
                              name="correct" id="flexRadioDefault1">
                            <label class="form-check-label" for="flexRadioDefault1">
                              A
                            </label>
                          </div>
                        </div>
                        <div class="col-2">
                          <div class="form-check">
                            <input class="form-check-input" wire:model="correct" value="B" type="radio"
                              name="correct" id="flexRadioDefault2">
                            <label class="form-check-label" for="flexRadioDefault2">
                              B
                            </label>
                          </div>
                        </div>
                        <div class="col-2">
                          <div class="form-check">
                            <input class="form-check-input" wire:model="correct" value="C" type="radio"
                              name="correct" id="flexRadioDefault3">
                            <label class="form-check-label" for="flexRadioDefault3">
                              C
                            </label>
                          </div>
                        </div>
                        <div class="col-2">
                          <div class="form-check">
                            <input class="form-check-input" wire:model="correct" value="D" type="radio"
                              name="correct" id="flexRadioDefault4">
                            <label class="form-check-label" for="flexRadioDefault4">
                              D
                            </label>
                          </div>
                        </div>
                        <div class="col-2">
                          <div class="form-check">
                            <input class="form-check-input" wire:model="correct" value="E" type="radio"
                              name="correct" id="flexRadioDefault5">
                            <label class="form-check-label" for="flexRadioDefault5">
                              E
                            </label>
                          </div>
                        </div>
                        <?php $__errorArgs = ['correct'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="text-danger">
                            <?php echo e($message); ?>

                          </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                      <div class="row my-3">
                        <div class="col-md-12 d-flex justify-content-between">
                          <?php if(Auth::guard('user')->check()): ?>
                            <a href="<?php echo e(route('admin.question.index', ['quiz' => $quiz->id])); ?>"
                              class="btn btn-primary">Kembali</a>
                          <?php elseif(Auth::guard('teacher')->check()): ?>
                            <a href="<?php echo e(route('teacher.question.index', ['quiz' => $quiz->id])); ?>"
                              class="btn btn-primary">Kembali</a>
                          <?php endif; ?>
                          <button type="submit" id="addQuestion" class="btn btn-primary">Simpan</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </section>
  <script>
    $(document).ready(function() {
      const question_body = CKEDITOR.replace('question_body', {
        filebrowserUploadUrl: "<?php echo e(route('ckUpload', ['_token' => csrf_token()])); ?>",
        filebrowserUploadMethod: 'form',
      });
      question_body.on('change', function(event) {
        window.livewire.find('<?php echo e($_instance->id); ?>').set('question_body', event.editor.getData());
      });
      const optionA = CKEDITOR.replace('optionA', {
        filebrowserUploadUrl: "<?php echo e(route('ckUpload', ['_token' => csrf_token()])); ?>",
        filebrowserUploadMethod: 'form',
      });
      optionA.on('change', function(event) {
        window.livewire.find('<?php echo e($_instance->id); ?>').set('optionA', event.editor.getData());
      });
      const optionB = CKEDITOR.replace('optionB', {
        filebrowserUploadUrl: "<?php echo e(route('ckUpload', ['_token' => csrf_token()])); ?>",
        filebrowserUploadMethod: 'form',
      });
      optionB.on('change', function(event) {
        window.livewire.find('<?php echo e($_instance->id); ?>').set('optionB', event.editor.getData());
      });
      const optionC = CKEDITOR.replace('optionC', {
        filebrowserUploadUrl: "<?php echo e(route('ckUpload', ['_token' => csrf_token()])); ?>",
        filebrowserUploadMethod: 'form',
      });
      optionC.on('change', function(event) {
        window.livewire.find('<?php echo e($_instance->id); ?>').set('optionC', event.editor.getData());
      });
      const optionD = CKEDITOR.replace('optionD', {
        filebrowserUploadUrl: "<?php echo e(route('ckUpload', ['_token' => csrf_token()])); ?>",
        filebrowserUploadMethod: 'form',
      });
      optionD.on('change', function(event) {
        window.livewire.find('<?php echo e($_instance->id); ?>').set('optionD', event.editor.getData());
      });
      const optionE = CKEDITOR.replace('optionE', {
        filebrowserUploadUrl: "<?php echo e(route('ckUpload', ['_token' => csrf_token()])); ?>",
        filebrowserUploadMethod: 'form',
      });
      optionE.on('change', function(event) {
        window.livewire.find('<?php echo e($_instance->id); ?>').set('optionE', event.editor.getData());
      });
    })
  </script>
</div>
<?php /**PATH C:\Penyimpanan Utama\Code\Web\Laravel\SmartExam\resources\views/livewire/admin-teacher/quiz/question/mc-edit.blade.php ENDPATH**/ ?>