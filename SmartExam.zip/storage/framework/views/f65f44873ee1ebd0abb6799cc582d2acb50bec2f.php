

<?php $__env->startPush('style'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('/css/table.css')); ?>">
  <style>
    .show-question {
      display: block;
    }

    .hide-question {
      display: none;
    }
  </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('body'); ?>
  <?php echo $__env->make('components.navbarStudent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('components.spasi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="page-wrapper pt-5">
    <?php if($quiz->quiz_type == 'MC'): ?>
      <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('student.quiz.quiz-work.mc-work', ['quiz' => $quiz])->html();
} elseif ($_instance->childHasBeenRendered('McAYEQU')) {
    $componentId = $_instance->getRenderedChildComponentId('McAYEQU');
    $componentTag = $_instance->getRenderedChildComponentTagName('McAYEQU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('McAYEQU');
} else {
    $response = \Livewire\Livewire::mount('student.quiz.quiz-work.mc-work', ['quiz' => $quiz]);
    $html = $response->html();
    $_instance->logRenderedChild('McAYEQU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php elseif($quiz->quiz_type == 'ES'): ?>
      <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('student.quiz.quiz-work.es-work', ['quiz' => $quiz])->html();
} elseif ($_instance->childHasBeenRendered('0onkasl')) {
    $componentId = $_instance->getRenderedChildComponentId('0onkasl');
    $componentTag = $_instance->getRenderedChildComponentTagName('0onkasl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0onkasl');
} else {
    $response = \Livewire\Livewire::mount('student.quiz.quiz-work.es-work', ['quiz' => $quiz]);
    $html = $response->html();
    $_instance->logRenderedChild('0onkasl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Penyimpanan Utama\Code\Web\Laravel\SmartExam\resources\views/student/quiz-work/index.blade.php ENDPATH**/ ?>