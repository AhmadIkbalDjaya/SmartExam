<?php if(session()->has('success')): ?>
  <div class="alert alert-success alert-dismissible fade show" role="alert">
    <div><?php echo e(session('success')); ?></div>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
<?php endif; ?>
<?php if(session()->has('failed')): ?>
  <div class="alert alert-danger alert-dismissible fade show" role="alert">
    <div><?php echo e(session('failed')); ?></div>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
<?php endif; ?>
<?php /**PATH C:\Penyimpanan Utama\Code\Web\Laravel\SmartExam\resources\views/components/alerts.blade.php ENDPATH**/ ?>