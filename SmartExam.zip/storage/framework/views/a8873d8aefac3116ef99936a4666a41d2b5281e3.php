<div class="page-breadcrumb">
  <!-- alerts -->
  <?php echo $__env->make('components.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Guru -->
  <section id="headerProduk" style="min-height: 75vh;">
    <div class="container-fluid card py-4 h-100">
      <div class="row">
        <div class="col-md-8">
          <div class="container-fluid">
            <div class="row p-3">
              <div class="col-md-12">
                <h3>Guru</h3>
                <p>Menambah, Mengedit, atau Menghapus Guru</p>
              </div>
              <div class="col-md-4">
                <button wire:click="resetField" type="button" class="btn btn-primary" data-bs-toggle="modal"
                  data-bs-target="#createModal">
                  Tambah Guru
                </button>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12 p-4">
                <div class="table-responsive">
                  <table class="table table-bordered text-center">
                    <thead>
                      <tr>
                        <th class="col-md-4">Username</th>
                        <th class="col-md-4">Sekolah</th>
                        <th class="col-md-4">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($teacher->username); ?></td>
                          <td><?php echo e($teacher->school->school_name); ?></td>
                          <td>
                            <button style=" border: none;background: none; padding: 0">
                              <span wire:click="setField(<?php echo e($teacher->id); ?>)" class="badge text-bg-info"
                                data-bs-toggle="modal" data-bs-target="#showModal">
                                Informasi
                              </span>
                            </button>
                            <button style=" border: none;background: none; padding: 0">
                              <span wire:click="edit(<?php echo e($teacher->id); ?>)" class="badge text-bg-warning px-4"
                                data-bs-toggle="modal" data-bs-target="#editModal">
                                Edit
                              </span>
                            </button>
                            <a href="#">
                              <span wire:click="setField(<?php echo e($teacher->id); ?>)" class="badge text-bg-danger"
                                data-bs-toggle="modal" data-bs-target="#deleteModal">
                                Delete
                              </span>
                            </a>
                          </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                  
                  <div wire:ignore.self class="modal fade" id="showModal" tabindex="-1"
                    aria-labelledby="showModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h1 class="modal-title fs-5" id="showModalLabel">Informasi</h1>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          <div class="container">
                            <div class="row">
                              <div class="col-md-12">
                                <div>
                                  <span> Username : </span>
                                  <span> <?php echo e($username); ?> </span>
                                </div>
                                <br>
                                <div>
                                  <span> Password : </span>
                                  <span> <?php echo e($password); ?> </span>
                                </div>
                                <br>
                                <div>
                                  <span> Sekolah : </span>
                                  <span> <?php echo e($school_name); ?> </span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <!-- Teacher Create Modal -->
                  <form wire:submit.prevent="store" method="POST">
                    <div wire:ignore.self class="modal fade" id="createModal" tabindex="-1"
                      aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Guru</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                            </button>
                          </div>
                          <div class="modal-body">
                            <div class="mb-3">
                              <label for="exampleFormControlInput1" class="form-label">Username</label>
                              <input type="text" wire:model="username" name="username" id="exampleFormControlInput1"
                                class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                              <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                  <?php echo e($message); ?>

                                </div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                              <label for="exampleFormControlInput1" class="form-label">Password</label>
                              <div class="input-group">
                                <input type="password" wire:model="password" name="password"
                                  class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="passwordInput">
                                <span class="input-group-append">
                                  <span class="input-group-text toggle-password" id="togglePassword"
                                    style="cursor: pointer">
                                    <i class="bi bi-eye-fill" alt="Show Password" id="eyeClosedIcon"></i>
                                    <i class="bi bi-eye-slash" alt="Hide Password" id="eyeOpenIcon"
                                      style="display: none;"></i>
                                  </span>
                                </span>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                  </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                            </div>
                            <select wire:model="school_id"
                              class="form-select <?php $__errorArgs = ['school_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="school_id"
                              aria-label="Default select example">
                              <option hidden>Pilih Sekolah</option>
                              <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($school->id); ?>">
                                  <?php echo e($school->school_name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['school_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback">
                                <?php echo e($message); ?>

                              </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>
                  <!-- Teacher Edit Modal -->
                  <form wire:submit.prevent="update(<?php echo e($teacher_id); ?>)" method="POST">
                    <div wire:ignore.self class="modal fade" id="editModal" tabindex="-1"
                      aria-labelledby="editModalLabel" aria-hidden="true">
                      <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h1 class="modal-title fs-5" id="editModalLabel">Edit Guru</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                              aria-label="Close"></button>
                          </div>
                          <div class="modal-body">
                            <div class="mb-3">
                              <label for="exampleFormControlInput1" class="form-label">Username</label>
                              <input wire:model="username" type="text" name="username"
                                id="exampleFormControlInput1"
                                class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required />
                              <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                  <?php echo e($message); ?>

                                </div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                              <label for="exampleFormControlInput1" class="form-label">Password</label>
                              
                              <div class="input-group">
                                <input type="password" wire:model="password" name="password"
                                  class="form-control
                                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                  id="passwordInput2">
                                <span class="input-group-append">
                                  <span class="input-group-text toggle-password" id="togglePassword2"
                                    style="cursor: pointer">
                                    <i class="bi bi-eye-fill" alt="Show Password" id="eyeClosedIcon2"></i>
                                    <i class="bi bi-eye-slash" alt="Hide Password" id="eyeOpenIcon2"
                                      style="display: none;"></i>
                                  </span>
                                </span>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                  </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                            </div>
                            <select wire:model="school_id"
                              class="form-select <?php $__errorArgs = ['school_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="school_id"
                              aria-label="Default select example">
                              <option hidden>Pilih Sekolah</option>
                              <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($school->id); ?>">
                                  <?php echo e($school->school_name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['school_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback">
                                <?php echo e($message); ?>

                              </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>
                  
                  <!-- Delete Modal -->
                  <div wire:ignore.self class="modal fade" id="deleteModal" tabindex="-1"
                    aria-labelledby="deleteModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h1 class="modal-title fs-5" id="deleteModalLabel">Hapus?</h1>
                          <button type="button" class="btn-close" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                        </div>
                        <div class="modal-body">Apakah anda yakin ingin menghapus <?php echo e($username); ?>?
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            Tidak
                          </button>
                          <button type="submit" wire:click="destroy(<?php echo e($teacher_id); ?>)"
                            class="btn btn-primary">Ya</button>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4 gambar1">
          <div class="container h-100">
            <div class="row align-items-center h-100">
              <div class="col-md-12">
                <img src="<?php echo e(asset('/images/teacher.svg')); ?>" alt="img" class="img-fluid" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
<?php /**PATH C:\Penyimpanan Utama\Code\Web\Laravel\SmartExam\resources\views/livewire/teacher/index.blade.php ENDPATH**/ ?>