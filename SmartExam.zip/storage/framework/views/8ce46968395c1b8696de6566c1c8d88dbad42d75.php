<div class="page-breadcrumb">
  <section id="quiz">
    <div class="container-fluid px-3">
      <div class="row">
        <div class="col-md-2">
          <div class="container card rounded-3 shadow-sm px-0">
            <div class="row">
              <div class="col-md-12 p-4">
                <div class="d-flex">
                  <p>Soal</p>
                  <h3 class="text-dark ps-2"><?php echo e($active_question); ?></h3>
                </div>
                <p>Selesaikan ujian tepat waktu !</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="card shadow-sm rounded-3">
            <div class="container px-1">
              <div class="row">
                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div
                    class="question-box 
                      <?php if($loop->iteration == $active_question): ?> show-question
                      <?php else: ?>
                        hide-question <?php endif; ?>
                      ">
                    <div class="col-md-12 p-4">
                      <div>
                        <?php echo $question->question; ?>

                      </div>
                      <?php $__currentLoopData = $question->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                          <input wire:model='selectedOptions.<?php echo e($question->id); ?>' value="<?php echo e($option->option); ?>"
                            class="form-check-input" type="radio"
                            name="question<?php echo e($question->id); ?>Option<?php echo e($option->id); ?>"
                            id="option<?php echo e($option->id); ?>" />
                          <label class="form-check-label d-flex" for="option<?php echo e($option->id); ?>">
                            <p>
                              <?php echo e($option->option); ?>.
                            </p>
                            <div>
                              <?php echo $option->option_body; ?>

                            </div>
                          </label>
                        </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <div class="row p-2">
                <div class="col-6">
                  <?php if($active_question != 1): ?>
                    <button wire:click="previousQuestion" type="button" class="btn btn-primary">
                      <i class="bi bi-arrow-left"></i>
                      Sebelumnya
                    </button>
                  <?php endif; ?>
                </div>
                <div class="col-6 text-end">
                  <?php if($active_question != $questions->count()): ?>
                    <button wire:click="nextQuestion" type="button" class="btn btn-primary">
                      Selanjutnya
                      <i class="bi bi-arrow-right"></i>
                    </button>
                  <?php endif; ?>
                  <button id="saveAnswer" wire:click="saveAnswer" type="submit" class="btn btn-primary d-none">Simpan
                    Jawaban</button>
                  <?php if($active_question == $questions->count()): ?>
                    <?php if(count($this->selectedOptions) == $question->count()): ?>
                      <button wire:click="saveAnswer" type="submit" class="btn btn-primary">Simpan Jawaban</button>
                    <?php else: ?>
                      <div class="text-danger">
                        Anda belum menjawab semua pertanyaan
                      </div>
                    <?php endif; ?>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card shadow-sm rounded-3">
            <div class="card-header">Semua Nomor</div>
            <div class="card-body p-0">
              <div class="container">
                <div class="row">
                  <div class="col-md-12 py-4">
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <button wire:click='setQuestion(<?php echo e($loop->iteration); ?>)' type="button"
                        class="btn p-0 mt-1 
                          <?php if($loop->iteration == $active_question): ?> btn-secondary
                          <?php elseif($selectedOptions[$question->id] ?? null): ?> btn-success
                          <?php else: ?> btn-info <?php endif; ?>"
                        style="height: 40px; width: 30px">
                        <?php echo e($loop->iteration); ?>

                      </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
                <div class="row py-4 pt-0 pb-2">
                  <div wire:ignore class="col-md-12 d-flex">
                    <p>Waktu Tersisa: </p>
                    <strong id="countdown" class="ps-3"></strong>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <?php $__env->startPush('script'); ?>
    <script>
      $(document).ready(function() {
        if (<?php echo json_encode($has_work, 15, 512) ?>) {
          window.location.href = "<?php echo e(route('student.quiz.index')); ?>";
        }
        // countdown
        var minutes = <?php echo json_encode($quiz->duration, 15, 512) ?>;
        var seconds = 60;
        var tempMinutes = minutes.toString().length > 1 ? minutes : `0${minutes}`;
        var tempSeconds = seconds.toString().length > 1 ? seconds : `0${seconds}`;
        $('#countdown').text(`${tempMinutes} : ${tempSeconds}`);

        // expire time
        var expireTime = <?php echo json_encode($quiz->end_time, 15, 512) ?>;
        // console.log(expireTime);
        // console.log("--------");
        var timer = setInterval(() => {
          // expire time
          var currentTime = $.now();
          var currentTime = moment(currentTime).format("YYYY-MM-DD HH:mm:ss")
          // console.log(currentTime);
          if (currentTime == expireTime) {
            clearInterval(timer);
            $("#saveAnswer").click();
          }

          if (minutes == 0 && seconds == 0) {
            clearInterval(timer);
            $("#saveAnswer").click();
          }
          if (seconds <= 0) {
            minutes--;
            seconds = 60;
          }
          var tempMinutes = minutes.toString().length > 1 ? minutes : `0${minutes}`;
          var tempSeconds = seconds.toString().length > 1 ? seconds : `0${seconds}`;
          $('#countdown').text(`${tempMinutes} : ${tempSeconds}`);
          seconds--;
        }, 1000);
      })
    </script>
  <?php $__env->stopPush(); ?>
</div>
<?php /**PATH C:\Penyimpanan Utama\Code\Web\Laravel\SmartExam\resources\views/livewire/student/quiz/quiz-work/mc-work.blade.php ENDPATH**/ ?>