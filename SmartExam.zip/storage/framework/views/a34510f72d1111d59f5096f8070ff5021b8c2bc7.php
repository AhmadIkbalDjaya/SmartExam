

<?php $__env->startPush('style'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('/css/table.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('body'); ?>
  <?php if(Auth::guard('user')->check()): ?>
    <?php echo $__env->make('components.navbarAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php elseif(Auth::guard('teacher')->check()): ?>
    <?php echo $__env->make('components.navbarTeacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>
  <?php echo $__env->make('components.spasi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="page-wrapper">
    <div class="page-breadcrumb">
      <!-- Profile -->
      <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin-teacher.profile.index', [])->html();
} elseif ($_instance->childHasBeenRendered('fy5kLPU')) {
    $componentId = $_instance->getRenderedChildComponentId('fy5kLPU');
    $componentTag = $_instance->getRenderedChildComponentTagName('fy5kLPU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fy5kLPU');
} else {
    $response = \Livewire\Livewire::mount('admin-teacher.profile.index', []);
    $html = $response->html();
    $_instance->logRenderedChild('fy5kLPU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <footer class="footer text-center">
      © 2023 CBT Online by <a
        href="https://l.instagram.com/?u=http%3A%2F%2Fbit.ly%2F3UaE7in&e=AT0IbESTXiAOKa7dxGjRS7TwV1mU3eagwftwzG-WUCjc6a8XKAWg_czE-a9qrlrI9tTvLMe5y4ckTmhdMcbKBXki7cKHOUaoYvnoa9s">Adrian.com</a>
    </footer>
  </div>

  <?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('/js/alerts.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/password.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/modal.js')); ?>"></script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Penyimpanan Utama\Code\Web\Laravel\SmartExam\resources\views/admin-teacher/profile/index.blade.php ENDPATH**/ ?>