

<?php $__env->startPush('style'); ?>
  
<?php $__env->stopPush(); ?>

<?php $__env->startSection('body'); ?>
  <?php if(Auth::guard('user')->check()): ?>
    <?php echo $__env->make('components.navbarAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php elseif(Auth::guard('teacher')->check()): ?>
    <?php echo $__env->make('components.navbarTeacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>
  <?php echo $__env->make('components.spasi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="page-wrapper">
    <div class="page-breadcrumb" style="min-height: 83vh">
      <div class="container h-100">
        <div class="row align-items-center h-100">
          <div class="col-md-12">
            <h1 class="text-center py-4">Data</h1>
            <div class="container">
              <div class="row">
                <div class="col-md-4">
                  <div class="card p-3 text-center rounded-4">
                    <h5>Jumlah Data Sekolah</h5>
                    <div style="height: 80px; width: 80px; margin: auto" class="rounded-circle bg-info">
                      <h3 style="margin-top: 28px">
                        <?php echo e($school_count); ?>

                      </h3>
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="card p-3 text-center rounded-4">
                    <h5>Jumlah Data Guru</h5>
                    <div style="height: 80px; width: 80px; margin: auto" class="rounded-circle bg-info">
                      <h3 style="margin-top: 28px">
                        <?php echo e($teacher_count); ?>

                      </h3>
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="card p-3 text-center rounded-4">
                    <h5>Jumlah Data Siswa</h5>
                    <div style="height: 80px; width: 80px; margin: auto" class="rounded-circle bg-info">
                      <h3 style="margin-top: 28px">
                        <?php echo e($student_count); ?>

                      </h3>
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="card p-3 text-center rounded-4">
                    <h5>Jumlah Data Ruangan</h5>
                    <div style="height: 80px; width: 80px; margin: auto" class="rounded-circle bg-info">
                      <h3 style="margin-top: 28px">32</h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <footer class="footer text-center">
      © 2023 CBT Online by <a
        href="https://l.instagram.com/?u=http%3A%2F%2Fbit.ly%2F3UaE7in&e=AT0IbESTXiAOKa7dxGjRS7TwV1mU3eagwftwzG-WUCjc6a8XKAWg_czE-a9qrlrI9tTvLMe5y4ckTmhdMcbKBXki7cKHOUaoYvnoa9s">Adrian.com</a>
    </footer>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Penyimpanan Utama\Code\Web\Laravel\SmartExam\resources\views/admin-teacher/dashboard/index.blade.php ENDPATH**/ ?>