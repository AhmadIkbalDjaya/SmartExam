

<?php $__env->startPush('style'); ?>
  <link rel="stylesheet" href="<?php echo e('/css/login.css'); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('body'); ?>
  <section id="login">
    <div class="container-fluid h-100">
      <div class="row h-100 align-items-center">
        <div class="col-12">
          <div class="row justify-content-center">
            <div class="col-md-9 text-center text-white">
              <h1>Computer Based Test</h1>
            </div>
          </div>
          <div class="row justify-content-center">
            <div class="col-11 col-md-5">
              <div class="login-box">
                <p>Login</p>
                <?php if(session()->has('loginError')): ?>
                  <p style="color: red; font-style: italic;" class="text-center">Username / Password Salah!</p>
                <?php endif; ?>
                <form action="<?php echo e(route('loginProcess')); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <div class="user-box">
                    <input required="" name="username" type="text" />
                    <label>Username</label>
                  </div>
                  <div class="user-box">
                    <input required="" name="password" type="password" />
                    <label>Password</label>
                  </div>
                  <button type="submit" name="login">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                    Submit
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Penyimpanan Utama\Code\Web\Laravel\SmartExam\resources\views/login.blade.php ENDPATH**/ ?>