<div class="page-breadcrumb">
  <!-- Question -->
  <section id="header">
    <div class="container-fluid card">
      <div class="row">
        <div class="col-md-12">
          <div class="container-fluid">
            <div class="row p-5">
              <div class="col-md-12 text-center">
                <h3><?php echo e($quiz->quiz_name); ?></h3>
                <p>Pilihan Ganda</p>
                <p></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- alerts -->
  <?php echo $__env->make('components.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  <section id="Soal">
    <div class="container-fluid card py-4 px-0">
      <div class="row">
        <div class="col-md-12">
          <div class="container-fluid ">
            <div class="row p-3 card-header shadow-sm">
              <div class="col-md-12">
                <h4 class="py-3">Edit Soal Ujian</h4>
                <form wire:submit.prevent="update(<?php echo e($question_id); ?>)" method="POST">
                  <div class="">
                    <label for="question_body">Pertanyaan</label>
                    <div wire:ignore>
                      <textarea name="question_body" id="question_body" rows="10" cols="80"><?php echo e($question_body); ?></textarea>
                    </div>
                  </div>
                  <div class="row my-3">
                    <div class="col-md-12 d-flex justify-content-between">
                      <?php if(Auth::guard('user')->check()): ?>
                        <a href="<?php echo e(route('admin.question.index', ['quiz' => $quiz->id])); ?>"
                          class="btn btn-primary">Kembali</a>
                      <?php elseif(Auth::guard('teacher')->check()): ?>
                        <a href="<?php echo e(route('teacher.question.index', ['quiz' => $quiz->id])); ?>"
                          class="btn btn-primary">Kembali</a>
                      <?php endif; ?>
                      <button type="submit" id="addQuestion" class="btn btn-primary">Simpan</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </section>
  <script>
    $(document).ready(function() {
      const question_body = CKEDITOR.replace('question_body');
      question_body.on('change', function(event) {
        window.livewire.find('<?php echo e($_instance->id); ?>').set('question_body', event.editor.getData());
      });
    });
  </script>
</div>
<?php /**PATH C:\Penyimpanan Utama\Code\Web\Laravel\SmartExam\resources\views/livewire/admin-teacher/quiz/question/es-edit.blade.php ENDPATH**/ ?>