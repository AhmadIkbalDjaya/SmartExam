

<?php $__env->startPush('style'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('/css/table.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('body'); ?>
  <?php echo $__env->make('components.navbarAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('components.spasi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="page-wrapper">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('school.index', [])->html();
} elseif ($_instance->childHasBeenRendered('LBnd4mh')) {
    $componentId = $_instance->getRenderedChildComponentId('LBnd4mh');
    $componentTag = $_instance->getRenderedChildComponentTagName('LBnd4mh');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LBnd4mh');
} else {
    $response = \Livewire\Livewire::mount('school.index', []);
    $html = $response->html();
    $_instance->logRenderedChild('LBnd4mh', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <footer class="footer text-center">
      © 2023 CBT Online by <a
        href="https://l.instagram.com/?u=http%3A%2F%2Fbit.ly%2F3UaE7in&e=AT0IbESTXiAOKa7dxGjRS7TwV1mU3eagwftwzG-WUCjc6a8XKAWg_czE-a9qrlrI9tTvLMe5y4ckTmhdMcbKBXki7cKHOUaoYvnoa9s">Adrian.com</a>
    </footer>
  </div>
  <?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('/js/password.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/alerts.js')); ?>"></script>
    <script src="<?php echo e(asset('js/modal.js')); ?>"></script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Penyimpanan Utama\Code\Web\Laravel\SmartExam\resources\views/admin/school/index.blade.php ENDPATH**/ ?>