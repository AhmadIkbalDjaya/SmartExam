

<?php $__env->startPush('style'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('/css/table.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('body'); ?>
  <?php echo $__env->make('components.spasi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="page-wrapper">
    <div class="page-breadcrumb">
      <!-- Print Quizz Recap -->
      <section id="header">
        <div class="container-fluid py-4">
          <div class="row">
            <div class="col-md-12">
              <form action="">
                <div class="row">
                  <div class="col-md-12">
                    <div class="container-fluid">
                      <div class="row p-3 border-bottom border-dark border-2">
                        <div class="col-2 text-end">
                          <img src="<?php echo e(asset('/images/logo.png')); ?>" alt="logo" height="70px">
                        </div>
                        <div class="col-8 text-center ">
                          <h3>Hasil Rekapan Quiz</h3>
                          <p>Hasil Rekapan Nilai Yang Mengikuti Ujian CBT</p>
                        </div>
                        <div class="col-2">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <div class="container-fluid">
                      <div class="row">
                        <div class="col-8 col-md-3">
                          <table class="table table-borderless">
                            <tbody>
                              <tr>
                                <td>Nama Quiz</td>
                                <td>:</td>
                                <td><?php echo e($quiz->quiz_name); ?></td>
                              </tr>
                              <tr>
                                <td>Sekolah</td>
                                <td>:</td>
                                <td><?php echo e($school_name); ?></td>
                              </tr>
                              <br />
                              <tr>
                                <td>Quiz</td>
                                <td>:</td>
                                <td>
                                  <?php if($quiz->quiz_type == 'MC'): ?>
                                    Pilihan Ganda
                                  <?php else: ?>
                                    Essay
                                  <?php endif; ?>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-12 p-4">
                          <div class="table-responsive">
                            <table class="table table-bordered text-center">
                              <thead>
                                <tr>
                                  <th class="">Rank</th>
                                  <th class="col-md-4">Nama Siswa</th>
                                  <th class="col-md-4">NISN</th>
                                  <th class="col-md-4">Sekolah</th>
                                  <th class="col-md-4">Nilai</th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php $__currentLoopData = $quizStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quizStudent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($quizStudent->student->name); ?></td>
                                    <td><?php echo e($quizStudent->student->username); ?></td>
                                    <td><?php echo e($quizStudent->student->school->school_name); ?></td>
                                    <td><?php echo e($quizStudent->score); ?></td>
                                  </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <a href="<?php echo e(route('admin.recap.quiz.index', ["quiz" => $quiz->id])); ?>">
                      <button type="button" class="btn btn-primary fs-6 print-button"><i
                          class="bi bi-arrow-left"></i></button>
                    </a>
                    <button type="button" class="btn btn-primary fs-6 print-button" onclick="window.print()"><i
                        class="bi bi-printer"></i></button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>

  <?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('/js/alerts.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/password.js')); ?>"></script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Penyimpanan Utama\Code\Web\Laravel\SmartExam\resources\views/admin-teacher/recap/quizRecap/print.blade.php ENDPATH**/ ?>