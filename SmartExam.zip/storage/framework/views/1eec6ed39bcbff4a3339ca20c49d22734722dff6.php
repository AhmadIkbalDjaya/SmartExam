

<?php $__env->startPush('style'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('/css/table.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('body'); ?>
  <?php if(Auth::guard('user')->check()): ?>
    <?php echo $__env->make('components.navbarAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php elseif(Auth::guard('teacher')->check()): ?>
    <?php echo $__env->make('components.navbarTeacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>
  <?php echo $__env->make('components.spasi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="page-wrapper">
    <div class="page-breadcrumb">
      <!-- Quizz Recap -->
      <section id="header">
        <div class="container-fluid card py-4">
          <div class="row">
            <div class="col-md-12">
              <div class="container-fluid">
                <div class="row p-3">
                  <div class="col-md-12 text-center">
                    <h3>Rekapan Quiz</h3>
                    <p><?php echo e($quiz->quiz_name); ?></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section id="header">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin-teacher.recap.show', ['quiz' => $quiz])->html();
} elseif ($_instance->childHasBeenRendered('3RYiwRq')) {
    $componentId = $_instance->getRenderedChildComponentId('3RYiwRq');
    $componentTag = $_instance->getRenderedChildComponentTagName('3RYiwRq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3RYiwRq');
} else {
    $response = \Livewire\Livewire::mount('admin-teacher.recap.show', ['quiz' => $quiz]);
    $html = $response->html();
    $_instance->logRenderedChild('3RYiwRq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
      </section>
    </div>
    <footer class="footer text-center">
      © 2023 CBT Online by <a
        href="https://l.instagram.com/?u=http%3A%2F%2Fbit.ly%2F3UaE7in&e=AT0IbESTXiAOKa7dxGjRS7TwV1mU3eagwftwzG-WUCjc6a8XKAWg_czE-a9qrlrI9tTvLMe5y4ckTmhdMcbKBXki7cKHOUaoYvnoa9s">Adrian.com</a>
    </footer>
  </div>

  <?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('/js/alerts.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/password.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/modal.js')); ?>"></script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Penyimpanan Utama\Code\Web\Laravel\SmartExam\resources\views/admin-teacher/recap/quizRecap/index.blade.php ENDPATH**/ ?>