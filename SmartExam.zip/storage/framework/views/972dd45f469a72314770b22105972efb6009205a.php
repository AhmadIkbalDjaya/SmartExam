<div class="page-breadcrumb">
  <!-- alerts -->
  <?php echo $__env->make('components.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Siswa -->
  <section id="headerProduk" style="min-height: 75vh;">
    <div class="container-fluid card py-4 h-100">
      <div class="row">
        <div class="col-md-8">
          <div class="container-fluid">
            <div class="row p-3">
              <div class="col-md-12">
                <h3>Siswa</h3>
                <p>Menambah, Mengedit, atau Menghapus Siswaa</p>
              </div>
              <div class="col-md-4">
                <button wire:click="resetField" type="button" class="btn btn-primary" data-bs-toggle="modal"
                  data-bs-target="#createModal">
                  Tambah Siswa
                </button>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12 p-4">
                <div class="table-responsive">
                  <table class="table table-bordered text-center">
                    <thead>
                      <tr>
                        <th class="col-md-4">Nisn</th>
                        <th class="col-md-4">Nama</th>
                        <th class="col-md-4">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($student->username); ?></td>
                          <td><?php echo e($student->name); ?></td>
                          <td>
                            <button style=" border: none;background: none; padding: 0">
                              <span class="badge text-bg-info" data-bs-toggle="modal"
                                data-bs-target="#showModal<?php echo e($student->id); ?>">
                                Informasi
                              </span>
                            </button>
                            <button style=" border: none;background: none; padding: 0">
                              <span class="badge text-bg-warning px-4" data-bs-toggle="modal"
                                data-bs-target="#editModal<?php echo e($student->id); ?>">
                                Edit
                              </span>
                            </button>
                            <a href="#">
                              <span class="badge text-bg-danger" data-bs-toggle="modal"
                                data-bs-target="#deleteModal<?php echo e($student->id); ?>">
                                Delete
                              </span>
                            </a>
                          </td>
                        </tr>

                        
                        
                        

                        <!-- Student Edit Modal -->
                        
                        <!-- End Student Edit Modal -->

                        <!-- Delete Modal -->
                        
                        <!-- End Delete Modal -->
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>

                  <!-- Student Create Modal -->
                  
                  

                  <button wire:click="store">tes</button>

                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4 gambar1">
          <div class="container h-100">
            <div class="row align-items-center h-100">
              <div class="col-md-12">
                <img src="<?php echo e(asset('/images/student.svg')); ?>" alt="img" class="img-fluid" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
<?php /**PATH C:\Penyimpanan Utama\Code\Web\Laravel\SmartExam\resources\views/livewire/student/index.blade.php ENDPATH**/ ?>